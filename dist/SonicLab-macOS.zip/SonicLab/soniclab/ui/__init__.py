"""PySide6 interface."""
