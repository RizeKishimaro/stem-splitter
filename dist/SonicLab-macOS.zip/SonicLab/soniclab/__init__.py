"""SonicLab desktop audio editor."""
